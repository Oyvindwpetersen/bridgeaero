function [neg_logL,neg_logL_grad]=ad_gpr_loglik2(test_matrix,y,hyper,theta)

%%

hyper.d=theta(hyper.idx_d);
hyper.sigma_v=theta(hyper.idx_sigma_v);
hyper.sigma=theta(hyper.idx_sigma);
hyper.L=theta(hyper.idx_L);
hyper.alpha=theta(hyper.idx_alpha);
hyper.abar=theta(hyper.idx_abar);

[neg_logL,neg_logL_grad]=ad_gpr_loglik(test_matrix,y,hyper);


