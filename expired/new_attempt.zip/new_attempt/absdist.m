function r=absdist(x1,x2,power)

%% Distance matrix in parameter space
%
% Inputs:
% x1: column vector
% x2: column vector
% power: exponent for distance measure 
%
% Outputs:
% r: distance matrix
%

%%

if ~isvector(x1) | ~isvector(x2)
    error('x1 and x2 must be vector');
end

if size(x1,2)>1
    error('Input must be column vector');
end

if size(x2,2)>1
    error('Input must be column vector');
end

% x1=x1(:);
% x2=x2(:);

r=abs(x1-x2.');

if nargin>2
    r=r.^power;
end
