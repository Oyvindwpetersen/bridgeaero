function B=blkdiag2(varargin)

%% Fast block diagonal
% Code same as blkdiag except overhead checks are removed
% In addition, blkdiag always gives out full matrices, even if inputs are sparse
% This code can give out sparse, which is faster
%
% Inputs:
% X1,X2,X3,... matrices to stack
% Add 'sparse' to end to preserve sparseness
%
% Outputs:
% B: block-diagonal matrix
%

%%

if isstr(varargin{end})

    % Assume string at end implies sparse output (if sparse input)

    B=matlab.internal.math.blkdiag(varargin{1:end-1});
else

    B=matlab.internal.math.blkdiag(varargin{:});

    % If sparse, make full
    if issparse(B)
        B=full(B);
    end

end
