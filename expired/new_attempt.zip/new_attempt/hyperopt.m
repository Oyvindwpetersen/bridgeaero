function hyper=hyperopt(varargin)

%% Options for kernel and hyperparameters
%
% Inputs:

%%

p=inputParser;
addParameter(p,'nd',3,@isnumeric)
addParameter(p,'kernel','se',@ischar)
addParameter(p,'noise','equal',@ischar)
addParameter(p,'basis','zero',@ischar)

addParameter(p,'sigma_v0',[1e-2],@isnumeric)
addParameter(p,'sigma0',[1],@isnumeric)
addParameter(p,'L0',[1],@isnumeric)
addParameter(p,'alpha0',[1],@isnumeric)
addParameter(p,'abar0',[1],@isnumeric)

addParameter(p,'sigma_v_lb',[1e-3],@isnumeric)
addParameter(p,'sigma_lb',[1e-1],@isnumeric)
addParameter(p,'L_lb',[1e-2],@isnumeric)
addParameter(p,'alpha_lb',[1e-2],@isnumeric)
addParameter(p,'abar_lb',[1e-2],@isnumeric)

addParameter(p,'sigma_v_ub',[1e1],@isnumeric)
addParameter(p,'sigma_ub',[1e2],@isnumeric)
addParameter(p,'L_ub',[1e1],@isnumeric)
addParameter(p,'alpha_ub',[1e1],@isnumeric)
addParameter(p,'abar_ub',[1e2],@isnumeric)

addParameter(p,'delta_d',0.05,@isnumeric)

parse(p,varargin{:})

nd=p.Results.nd;
kernel=p.Results.kernel;
noise=p.Results.noise;
basis=p.Results.basis;

sigma_v0=p.Results.sigma_v0;
sigma0=p.Results.sigma0;
L0=p.Results.L0;
alpha0=p.Results.alpha0;
abar0=p.Results.abar0;

sigma_v_lb=p.Results.sigma_v_lb;
sigma_lb=p.Results.sigma_lb;
L_lb=p.Results.L_lb;
alpha_lb=p.Results.alpha_lb;
abar_lb=p.Results.abar_lb;

sigma_v_ub=p.Results.sigma_v_ub;
sigma_ub=p.Results.sigma_ub;
L_ub=p.Results.L_ub;
alpha_ub=p.Results.alpha_ub;
abar_ub=p.Results.abar_ub;

delta_d=p.Results.delta_d;

%%

if ~( strcmpi(kernel,'se') | strcmpi(kernel,'matern52') | strcmpi(kernel,'rq') )
    error(['Kernel option not permissible: ' kernel]);
end

if ~( strcmpi(noise,'equal') | strcmpi(noise,'nonequal') | strcmpi(noise,'a') )
    error(['Noise option not permissible: ' noise]);
end

if ~( strcmpi(basis,'constant') | strcmpi(basis,'zero') )
    error(['Basis option not permissible: ' basis]);
end

%%

if strcmpi(noise,'equal')
    nv=1;
elseif strcmpi(noise,'nonequal')
    nv=2;
elseif strcmpi(noise,'a')
    nv=2;
end

na=nd+2;

% Ensure colum
sigma_v0=sigma_v0(:);
sigma0=sigma_v0(:);
L0=L0(:);
alpha0=alpha0(:);
abar0=abar0(:);

% If scalars given, expand to vector
if length(sigma_v0)==1
    sigma_v0=sigma_v0*ones(nv,1);
end

if length(sigma0)==1
    sigma0=sigma0*ones(na,1);
end

if length(L0)==1
    L0=L0*ones(na,1);
end

if length(alpha0)==1
    alpha0=alpha0*ones(na,1);
end

if length(abar0)==1
    abar0=abar0*ones(na,1);
end

if ~strcmpi(kernel,'rq')
    alpha0=[];
    alpha_lb=[];
    alpha_ub=[];
end

if strcmpi(basis,'zero')
    abar0=[];
    abar_lb=[];
    abar_ub=[];
end

%% Assign

hyper.nd=nd;
hyper.na=na;
hyper.nv=nv;
hyper.kernel=kernel;
hyper.noise=noise;
hyper.basis=basis;

hyper.idx_d=[1:nd];
hyper.idx_sigma_v=hyper.idx_d(end)+[1:nv];
hyper.idx_sigma=hyper.idx_sigma_v(end)+[1:na];
hyper.idx_L=hyper.idx_sigma(end)+[1:na];

if strcmpi(kernel,'rq')
    hyper.idx_alpha=hyper.idx_L(end)+[1:na];
else
    hyper.idx_alpha=[];
end

if strcmpi(basis,'constant')
    hyper.idx_abar=hyper.idx_L(end)+[1:na];

    if strcmpi(kernel,'rq')
        hyper.idx_abar=hyper.idx_abar+na;
    end
else
    hyper.idx_abar=[];
end

hyper.sigma_v0=sigma_v0;
hyper.sigma0=sigma0;
hyper.L0=L0;
hyper.alpha0=alpha0;
hyper.abar0=abar0;

hyper.sigma_v_lb=sigma_v_lb;
hyper.sigma_lb=sigma_lb;
hyper.L_lb=L_lb;
hyper.alpha_lb=alpha_lb;
hyper.abar_lb=abar_lb;

hyper.sigma_v_ub=sigma_v_ub;
hyper.sigma_ub=sigma_ub;
hyper.L_ub=L_ub;
hyper.alpha_ub=alpha_ub;
hyper.abar_ub=abar_ub;

hyper.delta_d=delta_d;


