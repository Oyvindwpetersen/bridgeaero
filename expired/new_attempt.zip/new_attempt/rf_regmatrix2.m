function [D_glob,x_uni,D_glob_grad]=rf_regmatrix2(data_matrix,d)

%%
%
% Inputs:
% data_matrix: matrix with K and x as columns
% d: vector with poles
%
% Outputs:
% D_glob: regression matrix
% x_uni: vector with unique x
% D_glob_grad: gradient of regression matrix with respect to poles
%
% data_matrix=
% [ K   x1  
%   .   .    
%   .   .    
%   .   .    
% ]

%%

% Find unique x
[x_uni,~,ic]=unique(data_matrix(:,2));
nx=length(x_uni);

% Create bins of index for each unique x
bins=cell(1,nx);
for k=1:length(x_uni)
    bins{k}=find(ic==k);
end

nx=length(bins);
% na=2+length(d);

% D-matrix for each unique x
Dr_blk=cell(nx,1);
Di_blk=cell(nx,1);
for k=1:nx
   K_vec=data_matrix(bins{k},1);
   [Dr_blk{k},Di_blk{k}]=rf_regmatrix(d,K_vec);
end
D_glob=[blkdiag2(Dr_blk{:}) ; blkdiag2(Di_blk{:})];

if nargout>2

    Dr_grad_blk=cell(nx,1);
    Di_grad_blk=cell(nx,1);
    for k=1:nx
       K_vec=data_matrix(bins{k},1);
       [Dr_grad_blk{k},Di_grad_blk{k}]=rf_regmatrix_grad(d,K_vec);
    end

    for j=1:length(d)

        Dr_grad_tmp=cell(nx,1);
        Di_grad_tmp=cell(nx,1);
        
        for k=1:nx
            Dr_grad_tmp{k}=Dr_grad_blk{k}{j};
            Di_grad_tmp{k}=Di_grad_blk{k}{j};
        end

        D_glob_grad{j}=[blkdiag2(Dr_grad_tmp{:}) ; blkdiag2(Di_grad_tmp{:})];
    end
    
end

