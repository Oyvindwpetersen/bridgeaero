function [Ka,Ky,beta,xt_uni,St,D_glob,N,Ka_grad,D_glob_grad,N_grad,abar_grad]=ad_gpr(test_matrix,y,hyper)

%%
%
% Inputs:
% test_matrix: column vector
% y: column vector
% hyper: struct with settings
%
% Outputs:
% Ka: covariance matrix for a
% Ky: covariance matrix for y
% beta: 
% xt_uni: unique values for 
% Sa: 
% D_glob:
% N:
% Ka_grad:
% D_glob_grad:
% N_grad:

%%

na=hyper.na;
d=hyper.d;
sigma_v=hyper.sigma_v;
sigma=hyper.sigma;
L=hyper.L;
alpha=hyper.alpha;
abar=hyper.abar;

%%

if size(test_matrix,1)~=length(y)/2
    error('');
end

[D_glob,xt_uni,D_glob_grad]=rf_regmatrix2(test_matrix,d);

nx=length(xt_uni);

[St,St_inv]=restack_a(na,nx);

% D_glob_t=full(D_glob*Sa);

%% Noise matrix

if strcmpi(hyper.noise,'equal')
    N=sigma_v^2*eye(length(y));
    N_grad{1}=2*sigma_v*eye(length(y));
elseif strcmpi(hyper.noise,'nonequal')
    N=blkdiag(sigma_v(1)^2*eye(length(y)/2),sigma_v(2)^2*eye(length(y)/2));
    N_grad{1}=blkdiag(sigma_v(1)^2*eye(length(y)/2),zeros(length(y)/2));
    N_grad{2}=blkdiag(zeros(length(y)/2),sigma_v(2)^2*eye(length(y)/2));
% elseif strcmpi(hyper.noise,'a')
    % N=D_glob_t*sigma_v(1)^2*eye(na*nx)*D_glob_t.'+sigma_v(2)^2*eye(length(y));
    % N_grad{1}=D_glob_t*2*sigma_v(1)*eye(na*nx)*D_glob_t.';
    % N_grad{2}=2*sigma_v(2)*eye(length(y));
else
    error(['Noise type not recognized:' hyper.noise]);
end


%% Kernel for a

% Kernel for a_restack
% a_restack=[a1(x1) a1(x2) .... a1(xN) , a2(x1) a2(x2) ... a2(xN) , a3(x1) a3(x2) ... a3(xN)];

Ka_blk=cell(1,na);
Ka_grad_tmp=cell(1,na);

for k=1:na
    if strcmpi(hyper.kernel,'se')
        [Ka_blk{k},Ka_grad_tmp{k}]=kernel_se(xt_uni,xt_uni,sigma(k),L(k));
        nh=2;
    elseif strcmpi(hyper.kernel,'matern52')
        [Ka_blk{k},Ka_grad_tmp{k}]=kernel_matern52(xt_uni,xt_uni,sigma(k),L(k));
        nh=2;
    elseif strcmpi(hyper.kernel,'rq')
        [Ka_blk{k},Ka_grad_tmp{k}]=kernel_rq(xt_uni,xt_uni,sigma(k),L(k),alpha(k));
        nh=3;
    else
        error(['Kernel type not recognized:' hyper.kernel]);
    end
end
Ka=blkdiag(Ka_blk{:});
Ka=St*Ka*St.';

% Ka_grad_tmp is given in cells for each a wrt. sigma1,L1, sigma2,L2,...
% Build as global matrix wrt. sigma1,sigma2,...,L1,L2,...

idx=0;
for n=1:nh

    for k=1:na
    
        idx=idx+1;
        range_col=(k-1)*nx+[1:nx];
        range_row=(k-1)*nx+[1:nx];

        tmp=zeros(size(Ka,1),size(Ka,2));
        tmp(range_col,range_row)=Ka_grad_tmp{k}{n};
        
        Ka_grad{idx}=tmp;
        Ka_grad{idx}=St*Ka_grad{idx}*St.';

    end
end

if strcmpi(hyper.basis,'constant')
    for k=1:na
        tmp=zeros(na,1); tmp(k)=abar(k);
        abar_grad{k,1}=tmp;
    end
else
    abar_grad={};
end

%%

Ky=(D_glob*Ka*D_glob.'+N);

beta=D_glob.'/Ky*y;

%%

