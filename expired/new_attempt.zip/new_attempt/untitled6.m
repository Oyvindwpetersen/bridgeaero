

clc
clear all
close all

importdata

%%

clc

nd=3;
na=nd+2;

hyper=hyperopt('nd',nd,'kernel','se','noise','nonequal');

hyper.d0=linspace(0.2,1.5,nd).';
% hyper.d0=[d1 d2 d3].'

hyper.sigma_v0=0.1;
hyper.sigma0=10*ones(na,1);
hyper.L0=2*ones(na,1);

hyper.d_lb=0.1*ones(nd,1);
hyper.sigma_v_lb=1e-3;
hyper.sigma_lb=1e-2*ones(na,1);
hyper.L_lb=1e-1*ones(na,1);

hyper.d_ub=2.0*ones(nd,1);
hyper.sigma_v_ub=1e1;
hyper.sigma_ub=1e2*ones(na,1);
hyper.L_ub=1e2*ones(na,1);

% hyper.alpha0=1*ones(na,1);
% hyper.alpha_lb=1e-1*ones(na,1);
% hyper.alpha_ub=1e2*ones(na,1);

% % rng(0);
% yt_r=real(F_test)+randn(size(F_test))*0.05;
% yt_i=imag(F_test)+randn(size(F_test))*0.05;

idx1=3;
idx2=3;

yt_r=[]; 
yt_i=[]; 
test_matrix=[]; 

yt_r(:,1)=data_K(idx1,idx2,:).^2.*data_AD_s(idx1,idx2,:);
yt_i(:,1)=data_K(idx1,idx2,:).^2.*data_AD_d(idx1,idx2,:);

test_matrix(:,1)=data_K(idx1,idx2,:);
test_matrix(:,2)=data_H(idx1,idx2,:);

%%

[d_opt,sigma_v_opt,sigma_opt,L_opt,alpha_opt]=ad_gpr_opt(test_matrix,yt_r,yt_i,hyper);

% hyper.d=d_opt;
% hyper.sigma_v=sigma_v_opt;
% hyper.sigma=sigma_opt;
% hyper.L=L_opt;
% hyper.alpha=alpha_opt;

rng(0)

d_opt_all=[]; sigma_v_opt_all=[]; sigma_opt_all=[]; L_opt_all=[]; logL_opt_all=[];
for k=1:2

hyper.d0=rand(size(hyper.d0)).*(hyper.d_ub-hyper.d_lb)+hyper.d_lb;
hyper.d0=sort(hyper.d0);
% hyper.d0=[d1 d2 d3].'

hyper.sigma0=rand(size(hyper.sigma0)).*(10-0);
hyper.L0=rand(size(hyper.L0)).*(3-1)+1;

[d_opt_all(:,k),sigma_v_opt_all(:,k),sigma_opt_all(:,k),L_opt_all(:,k),~,logL_opt_all(:,k)]=ad_gpr_opt(test_matrix,yt_r,yt_i,hyper);
%alpha_opt_all(:,k)
end

[logL_opt,idx_min]=min(logL_opt_all)

hyper.d=d_opt_all(:,idx_min);
hyper.sigma_v=sigma_v_opt_all(:,idx_min);
hyper.sigma=sigma_opt_all(:,idx_min);
hyper.L=L_opt_all(:,idx_min);
hyper.alpha=[];

%%

x_plot=[4.5:0.1:6.5].';
% x_plot=[5:0.1:7.5].';

K_plot=[0:0.05:1.5].';
plot_matrix=gridvec(K_plot,x_plot);


clc

[yp,yp_r,yp_i,std_yp_r,std_yp_i,a_pred,cov_a_pred]=ad_gpr_pred(test_matrix,plot_matrix,[yt_r;yt_i],hyper); 

% close all

plotopt=struct();
plotopt.xlabel='K';
plotopt.ylabel='x';
plotopt.view=[-105 30];
plotopt.view=[50 45];
plotopt.linestyle='-';
plotopt.linewidth=0.1;
plotopt.cbar=[0.5 1 0 0.1];
plotopt.cbar=NaN;
plotopt.xtick=[0 1];
plotopt.ytick=[2:2:8]


plotopt2=struct();
plotopt2.marker='o';
plotopt2.markersize=10;
plotopt2.color=[0 0 0];
plotopt2.linestyle='None';

figure(); 
ha=tight_subplot(2,2,[0.2 0.075],[0.15 0.15],[0.05 0.05]);

axes(ha(1)); hold on; grid on;
title('Prediction','FontWeight','normal');
surfiso(plot_matrix,yp_r,plotopt,'zlabel','K^2 H_1^*');
plot3(test_matrix(:,1),test_matrix(:,2),yt_r,plotopt2);

axes(ha(3)); hold on; grid on;
surfiso(plot_matrix,yp_i,plotopt,'zlabel','K^2 H_4^*');
plot3(test_matrix(:,1),test_matrix(:,2),yt_i,plotopt2);




axes(ha(2)); hold on; grid on;
title('Prediction uncertainty','FontWeight','normal');
surfiso(plot_matrix,std_yp_r,plotopt,'zlabel','K^2 H_1^*');
zlim([0 0.05]);
% 
axes(ha(4)); hold on; grid on;
surfiso(plot_matrix,std_yp_i,plotopt,'zlabel','K^2 H_4^*');
zlim([0 0.05]);

tilefigs
% plotscriptmain('h',5,'w',15,'name','Numerical_ex','labelsize',6,'ticksize',6,'legendsize',6,'titlesize',8,'format',{'jpg'});

%%

% close all

xt_uni=uniquetol(test_matrix(:,2));

figure();
ha=tight_subplot(2,length(xt_uni),[0.2 0.125],[0.15 0.15],[0.05 0.05]);

for k=1:length(xt_uni)

%5.25-2;
K_pred=[0:0.05:1.5].';


idx_h=find(ismembertol(test_matrix(:,2),xt_uni(k)));

pred_matrix=gridvec(K_pred,xt_uni(k));

[y_pred,yr_pred,yi_pred,std_yp_r,std_yp_i]=ad_gpr_pred(test_matrix,pred_matrix,[yt_r;yt_i],hyper); 

F_plot2_r=yt_r(idx_h);
F_plot2_i=yt_i(idx_h);

% close all

axes(ha(k)); hold on; grid on;
plot(test_matrix(idx_h,1),F_plot2_r,'o')
plot(K_pred,yr_pred)
h_shade=plotci(K_pred,yr_pred,std_yp_r,2);

axes(ha(k+length(xt_uni))); hold on; grid on;
plot(test_matrix(idx_h,1),F_plot2_i,'o')
plot(K_pred,yi_pred)
h_shade=plotci(K_pred,yi_pred,std_yp_i,2);

tilefigs


end

%%











