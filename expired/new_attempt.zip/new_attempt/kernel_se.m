function [K,K_grad]=kernel_se(X1,X2,sigma,L)

%% Squared exponential kernel
%
% Inputs:
% X1: matrix with inputs as columns
% X2: matrix with inputs as column
% sigma: vector with magnitudes
% L: vector with length scales
%
% Outputs:
% K: covariance matrix
% K_grad: cell with gradients
%
% K=sigma^2*prod{ exp(-0.5*r_i^2/L_i^2) }
%
% dK/dsigma=2*sigma*prod{ exp(-0.5*r_i^2/L_i^2 }
%
% dK/dL_n=(r_n^2/L_n^3)*sigma^2*prod{ exp(-0.5*r_i^2/L_i^2) }
%
%% Kernel

if size(X1,2)~=size(X2,2)
    error('Wrong size of x');
end

if size(X1,2)>1
    error('Multiple dimension x not supported yet');
end

%%

n=1;
K=sigma^2*exp(-0.5*absdist(X1(:,n),X2(:,n),2)/L(n)^2);

for n=2:length(L)
    K=K.*exp(-0.5*absdist(X1(:,n),X2(:,n),2)/L(n)^2);
end

%% Gradient

if nargout>1
    n=1;
    K_grad{1}=2*sigma/sigma^2*K;
    K_grad{2}=absdist(X1(:,n),X2(:,n),2)./L(n)^3.*K;
    
    % If 
    for n=2:length(L)
    
        K_grad{n+2}=absdist(X1(:,n),X2(:,n),2)./L(n)^3.*K;
    
    end

end

