function [d_opt,sigma_v_opt,sigma_opt,L_opt,alpha_opt,abar_opt,logL_opt]=ad_gpr_opt(test_matrix,yt_r,yt_i,hyper)

%% Assign initial and bounds

theta0(hyper.idx_d,1)=hyper.d0;
theta0(hyper.idx_sigma_v,1)=hyper.sigma_v0;
theta0(hyper.idx_sigma,1)=hyper.sigma0;
theta0(hyper.idx_L,1)=hyper.L0;
theta0(hyper.idx_alpha,1)=hyper.alpha0;
theta0(hyper.idx_abar,1)=hyper.abar0;

theta_lb(hyper.idx_d,1)=hyper.d_lb;
theta_lb(hyper.idx_sigma_v,1)=hyper.sigma_v_lb;
theta_lb(hyper.idx_sigma,1)=hyper.sigma_lb;
theta_lb(hyper.idx_L,1)=hyper.L_lb;
theta_lb(hyper.idx_alpha,1)=hyper.alpha_lb;
theta_lb(hyper.idx_abar,1)=hyper.abar_lb;

theta_ub(hyper.idx_d,1)=hyper.d_ub;
theta_ub(hyper.idx_sigma_v,1)=hyper.sigma_v_ub;
theta_ub(hyper.idx_sigma,1)=hyper.sigma_ub;
theta_ub(hyper.idx_L,1)=hyper.L_ub;
theta_ub(hyper.idx_alpha,1)=hyper.alpha_ub;
theta_ub(hyper.idx_abar,1)=hyper.abar_ub;

%%

% D_glob=diag(D_r1,D_r2,...,D_i1,D_i2,...)

% a=Sa*a_res;
% Kernel is created for restacked a

% | b_r(x1,K1) | = | D_r(K1)   0     | | a(x1) |
% | b_r(x2,K2) |   | 0       D_r(K2) | | a(x2) |
% | b_i(x1,K1) |   | D_i(K1)    0    | 
% | b_i(x2,K2) |   |  0      D_i(K2) | 
%

% b=D*a_ori=D*Sa*a;

%%

y=[yt_r ; yt_i];

fun_obj= @(theta) ad_gpr_loglik2(test_matrix,y,hyper,theta);

options = optimoptions('fmincon','Display','iter','TypicalX',theta0,'ConstraintTolerance',1e-3,'OptimalityTolerance',1e-3,'StepTolerance',1e-6... ); %,...
    ,'CheckGradients',false,'Algorithm','interior-point','SpecifyObjectiveGradient',true);
% trust-region-reflective

% Constraint to separate deltas
A=zeros(hyper.nd-1,length(theta0));
for k=1:(hyper.nd-1)
    A(k,k-1+[1:2])=[1 -1];
end
b=-hyper.delta_d*ones(hyper.nd-1,1);

[theta_opt,logL_opt]=fmincon(fun_obj,theta0,A,b,[],[],theta_lb,theta_ub,[],options);

d_opt=theta_opt(hyper.idx_d);
sigma_v_opt=theta_opt(hyper.idx_sigma_v);
sigma_opt=theta_opt(hyper.idx_sigma);
L_opt=theta_opt(hyper.idx_L);
alpha_opt=theta_opt(hyper.idx_alpha);
abar_opt=theta_opt(hyper.idx_abar);



%%

% options=DLASopt('x0',theta0,'x_lb',theta_lb,'x_ub',theta_ub,'ShowText',true,'PerturbType','decay','halflife',200)
% 
% fun_obj= @(theta) ad_gpr_loglik(test_matrix,y,hyper,theta);
% 
% [S_star,F_star]=DLAS(fun_obj,options);

% [grad_num,err,finaldelta] = gradest(fun_obj,theta0)
% [a,grad_pred]=fun_obj(theta0);
% ratio=grad_pred./grad_num'-1

% rng default % For reproducibility
% ms = MultiStart;
% 
% problem = createOptimProblem('fmincon','x0',theta0,'objective',fun_obj,'lb',theta_lb,'ub',theta_ub);
% 
% 
% [xmin,fmin,flag,outpt,allmins] = run(ms,problem,30);


% options = optimoptions('fmincon','Display','iter','Algorithm','interior-point','MaxFunctionEvaluations',3e3,'MaxIterations',100,'StepTolerance',1e-3,...
%     'FunctionTolerance',1e2,'FiniteDifferenceStepSize',1e-6,'ConstraintTolerance',1e-3,'ScaleProblem','obj-and-constr','UseParallel',false); % obj-and-constr %active-set
% 
% 
% options = optimoptions('fmincon','Display','iter','TypicalX',theta0... ); %,...
%     ,'CheckGradients',false,'Algorithm','interior-point','SpecifyObjectiveGradient',true);
% 
% problem = createOptimProblem('fmincon','objective',fun_obj,'x0',theta0,'lb',theta_lb,'ub',theta_ub,'options',options);
% 
% 
% gs=GlobalSearch;
% gs.FunctionTolerance=1e0;
% gs.XTolerance=1e-5;
% gs.StartPointsToRun='bounds-ineqs';
% gs.NumStageOnePoints=10; %200
% gs.NumTrialPoints=100; %1000
% 
% t0=tic;
% [x_opt_glob,~,~,~,manymins]=run(gs,problem);
% t1=toc(t0);

