function [neg_logL,neg_logL_grad]=ad_gpr_loglik(test_matrix,y,hyper)

%%

[Ka,Ky,beta,xt_uni,St,D_glob,N,Ka_grad,D_glob_grad,N_grad,abar_grad]=ad_gpr(test_matrix,y,hyper);

% D_glob_t=D_glob*Sa;

%% Likelihood to be maximized

% logL_bias=-0.5*y.'/Ky*y;

if isempty(hyper.idx_abar)
    e=y;
else
    m=D_glob*repmat(hyper.abar,length(xt_uni),1);
    e=y-m;
end

Ky_inv_e=Ky\e;

logL_bias=-0.5*e.'*Ky_inv_e;

% log_det_Ky_trad=log(det(Ky));

% [u,s,v]=svd(Ky); s=diag(s);
% log_det_Ky_svd=sum(log(s));

% Cholesky decomposition
L=chol(Ky,'lower');
log_det_Ky_chol=2*sum(log(diag(L)));

% disp(['Ratio trad=' num2str(log_det_Ky_trad/log_det_Ky_svd,'%0.3e')])
% disp(['Ratio chol=' num2str(log_det_Ky_chol/log_det_Ky_svd,'%0.3e')])

logL_var=-0.5*log_det_Ky_chol;

logL=logL_bias+logL_var;

%%

n_par=length(hyper.idx_d)+length(hyper.idx_sigma_v)+length(hyper.idx_sigma)+length(hyper.idx_L)+length(hyper.idx_alpha)+length(hyper.idx_abar);

% D_glob_grad_t=cell(n_par,1);
% for j=1:n_par
%     if any(j==hyper.idx_d)
%         D_glob_grad_t{j}=D_glob_grad{j}*Sa;
%     end
% end

Ky_grad=cell(n_par,1);
mean_grad=cell(n_par,1);

for j=1:n_par

    Ky_grad{j}=sparse(length(y),length(y));
    mean_grad{j}=sparse(hyper.na,1);

    if any(j==hyper.idx_d)
        Ky_grad{j}=D_glob_grad{j}*Ka*D_glob.'+D_glob*Ka*D_glob_grad{j}.';

        if strcmpi(hyper.noise,'a')
            Ky_grad{j}=Ky_grad{j}+D_glob_grad{j}*hyper.sigma_v(1)^2*D_glob.'+D_glob*hyper.sigma_v(1)^2*D_glob_grad{j}.';
        end

    elseif any(j==hyper.idx_sigma_v)
        idx=j-length(hyper.idx_d);
        Ky_grad{j}=N_grad{idx};
    elseif any(j==hyper.idx_sigma) | any(j==hyper.idx_L) | any(j==hyper.idx_alpha)
        idx=j-length(hyper.idx_d)-length(hyper.idx_sigma_v);
        Ky_grad{j}=D_glob*Ka_grad{idx}*D_glob.';
    elseif any(j==hyper.idx_abar)
        idx=j-length(hyper.idx_d)-length(hyper.idx_sigma_v)-length(hyper.idx_sigma)-length(hyper.idx_L)-length(hyper.idx_alpha);
        mean_grad{j}=repmat(abar_grad{idx},length(xt_uni),1);
    end
    
end

logL_grad=nan*ones(n_par,1);

for j=1:n_par

    % logL_grad(j,1)=0.5*y.'/Ky*Ky_grad{j}/Ky*y-0.5*trace(Ky\Ky_grad{j});
    % logL_grad(j,1)=0.5*(Ky_inv_y).'*Ky_grad{j}*Ky_inv_y-0.5*trace(Ky\Ky_grad{j});

    if any(j==hyper.idx_d) | any(j==hyper.idx_sigma_v) | any(j==hyper.idx_sigma) | any(j==hyper.idx_L) | any(j==hyper.idx_alpha)
        logL_grad(j,1)=0.5*(Ky_inv_e).'*Ky_grad{j}*Ky_inv_e-0.5*trace(L.' \ (L \Ky_grad{j}));
    elseif any(j==hyper.idx_abar)
        logL_grad(j,1)=-0.5*(-D_glob*mean_grad{j}).'*Ky_inv_e*2;
    end

end

if any(isnan(logL_grad))
    logL_grad
    error('Gradient is NaN, aborting');
end

if any(isinf(logL_grad))
    logL_grad
    error('Gradient is Inf, aborting');
end

neg_logL=-logL;
neg_logL_grad=-logL_grad;
