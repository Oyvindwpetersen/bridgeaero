

clc
clear all
close all

Generate_data

%%

clc

nd=3;
na=nd+2;

hyper=hyperopt('nd',nd,'kernel','se','noise','nonequal','basis','zero');

hyper.d0=linspace(0.2,1.5,nd).';
% hyper.d0=[d1 d2 d3].'

hyper.sigma_v0=0.1;
hyper.sigma0=10*ones(na,1);
hyper.L0=2*ones(na,1);

hyper.d_lb=0.1*ones(nd,1);
hyper.sigma_v_lb=1e-3;
hyper.sigma_lb=1e-1*ones(na,1);
hyper.L_lb=1e-1*ones(na,1);

hyper.d_ub=2.0*ones(nd,1);
hyper.sigma_v_ub=1e1;
hyper.sigma_ub=1e2*ones(na,1);
hyper.L_ub=1e1*ones(na,1);

% hyper.alpha0=1*ones(na,1);
% hyper.alpha_lb=1e-1*ones(na,1);
% hyper.alpha_ub=1e2*ones(na,1);

rng(0);
yt_r=real(F_test)+randn(size(F_test))*0.05;
yt_i=imag(F_test)+randn(size(F_test))*0.05;

%%

[d_opt,sigma_v_opt,sigma_opt,L_opt,alpha_opt,abar_opt]=ad_gpr_opt(test_matrix,yt_r,yt_i,hyper);

% hyper.d=d_opt;
% hyper.sigma_v=sigma_v_opt;
% hyper.sigma=sigma_opt;
% hyper.L=L_opt;
% hyper.alpha=alpha_opt;

rng(0)

for k=1:2

hyper.d0=rand(size(hyper.d0)).*(hyper.d_ub-hyper.d_lb)+hyper.d_lb;
hyper.d0=sort(hyper.d0);
% hyper.d0=[d1 d2 d3].'

hyper.sigma0=rand(size(hyper.sigma0)).*(10-0);
hyper.L0=rand(size(hyper.L0)).*(3-1)+1;

[d_opt_all(:,k),sigma_v_opt_all(:,k),sigma_opt_all(:,k),L_opt_all(:,k),~,~,logL_opt_all(:,k)]=ad_gpr_opt(test_matrix,yt_r,yt_i,hyper);
%alpha_opt_all(:,k)
end

[~,idx_min]=min(logL_opt_all)

hyper.d=d_opt_all(:,idx_min);
hyper.sigma_v=sigma_v_opt_all(:,idx_min);
hyper.sigma=sigma_opt_all(:,idx_min);
hyper.L=L_opt_all(:,idx_min);
hyper.alpha=[];
% hyper.abar=abar_opt_all(:,idx_min);
hyper.abar=[];

%%

clc

[yp,yp_r,yp_i,std_yp_r,std_yp_i,a_pred,cov_a_pred]=ad_gpr_pred(test_matrix,plot_matrix,[yt_r;yt_i],hyper); 

close all

plotopt=struct();
plotopt.xlabel='K';
plotopt.ylabel='x';
plotopt.view=[-105 30];
plotopt.linestyle='-';
plotopt.linewidth=0.1;
plotopt.cbar=[0.5 1 0 0.1];
plotopt.cbar=NaN;
plotopt.xtick=[0 1];
plotopt.ytick=[2:2:8]


plotopt2=struct();
plotopt2.marker='o';
plotopt2.markersize=1;
plotopt2.color=[0 0 0];
plotopt2.linestyle='None';

figure(); 
ha=tight_subplot(2,4,[0.2 0.075],[0.15 0.15],[0.05 0.05]);

axes(ha(1)); hold on; grid on;
title('Truth','FontWeight','normal');
surfiso(plot_matrix,real(F_plot),plotopt,'zlabel','K^2 H_1^*');
plot3(test_matrix(:,1),test_matrix(:,2),yt_r,plotopt2);
%zlim([-2 4]);

axes(ha(1+4)); hold on; grid on;
surfiso(plot_matrix,imag(F_plot),plotopt,'zlabel','K^2 H_4^*');
plot3(test_matrix(:,1),test_matrix(:,2),yt_i,plotopt2);
%zlim([0 5]);

axes(ha(2)); hold on; grid on;
title('Prediction','FontWeight','normal');
surfiso(plot_matrix,yp_r,plotopt,'zlabel','K^2 H_1^*');
%zlim([-2 4]);

axes(ha(2+4)); hold on; grid on;
surfiso(plot_matrix,yp_i,plotopt,'zlabel','K^2 H_4^*');
%zlim([0 5]);

axes(ha(3)); hold on; grid on;
title('Error (abs.)','FontWeight','normal');
surfiso(plot_matrix,abs(real(F_plot)-yp_r),plotopt,'zlabel','K^2 H_1^*');
%zlim([0 2]);

axes(ha(3+4)); hold on; grid on;
surfiso(plot_matrix,abs(imag(F_plot)-yp_i),plotopt,'zlabel','K^2 H_4^*');
%zlim([0 2]);

axes(ha(4)); hold on; grid on;
title('Prediction uncertainty','FontWeight','normal');
surfiso(plot_matrix,std_yp_r,plotopt,'zlabel','K^2 H_1^*');
%zlim([0 2]);

axes(ha(4+4)); hold on; grid on;
surfiso(plot_matrix,std_yp_i,plotopt,'zlabel','K^2 H_4^*');
%zlim([0 2]);

% plotscriptmain('h',5,'w',15,'name','Numerical_ex','labelsize',6,'ticksize',6,'legendsize',6,'titlesize',8,'format',{'jpg'});
return
%%

x_pred=4 %5.25-2;
K_pred=[0:0.05:1.5].';

pred_matrix=gridvec(K_pred,x_pred);

[y_pred,yr_pred,yi_pred,std_yp_r,std_yp_i]=ad_gpr_pred(test_matrix,pred_matrix,[yt_r;yt_i],hyper); 

F_plot2=F_fun(pred_matrix(:,1),pred_matrix(:,2));

% close all

figure(); hold on; grid on;
plot(K_pred,real(F_plot2))
plot(K_pred,yr_pred)
h_shade=plotci(K_pred,yr_pred,std_yp_r,2);

figure(); hold on; grid on;
plot(K_pred,imag(F_plot2))
plot(K_pred,yi_pred)
h_shade=plotci(K_pred,yi_pred,std_yp_i,2);

tilefigs

%%











