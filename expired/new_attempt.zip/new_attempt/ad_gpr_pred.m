function [y_pred,yr_pred,yi_pred,std_yr_pred,std_yi_pred,a_pred,cov_a_pred]=ad_gpr_pred(test_matrix,pred_matrix,y,hyper)

%%

d=hyper.d;
sigma_v=hyper.sigma_v;
sigma_a=hyper.sigma;
L_a=hyper.L;
alpha_a=hyper.alpha;

%%

[Ka,Ky,alpha_pred,xt_uni,Sa,D_glob]=ad_gpr(test_matrix,y,hyper);

na=length(sigma_a);

[D_glob_pred,xp_uni]=rf_regmatrix2(pred_matrix,d);
[Sa_pred]=restack_a(na,length(xp_uni));

Ka_star_t_blk=cell(1,na);
for k=1:na
    if strcmpi(hyper.kernel,'se')
        Ka_star_t_blk{k}=kernel_se(xp_uni,xt_uni,sigma_a(k),L_a(k));
    elseif strcmpi(hyper.kernel,'matern52')
        Ka_star_t_blk{k}=kernel_matern52(xp_uni,xt_uni,sigma_a(k),L_a(k));
    elseif strcmpi(hyper.kernel,'rq')
        Ka_star_t_blk{k}=kernel_rq(xp_uni,xt_uni,sigma_a(k),L_a(k),alpha_a(k));
    end
end
Ka_star_t=blkdiag2(Ka_star_t_blk{:});
Ka_star_t_NEW=Sa_pred*blkdiag2(Ka_star_t_blk{:})*Sa.';

a_pred=Ka_star_t*alpha_pred;

% y_pred=D_glob_pred*Sa_pred*a_pred;
y_pred=D_glob_pred*a_pred;

yr_pred=y_pred(1:length(y_pred)/2);

yi_pred=y_pred((length(y_pred)/2+1):end);

%% Uncertainty

Ka_star_star_t_blk=cell(1,na);
for k=1:na
    if strcmpi(hyper.kernel,'se')
        Ka_star_star_t_blk{k}=kernel_se(xp_uni,xp_uni,sigma_a(k),L_a(k));
    elseif strcmpi(hyper.kernel,'matern52')
        Ka_star_star_t_blk{k}=kernel_matern52(xp_uni,xp_uni,sigma_a(k),L_a(k));
    elseif strcmpi(hyper.kernel,'rq')
        Ka_star_star_t_blk{k}=kernel_rq(xp_uni,xp_uni,sigma_a(k),L_a(k),alpha_a(k));
    end
end
Ka_star_star_t=blkdiag2(Ka_star_star_t_blk{:});

% Uncertainty of a
cov_a_pred=Ka_star_star_t-Ka_star_t*(D_glob*Sa).'/Ky*(D_glob*Sa)*Ka_star_t.';

cov_y_pred=(D_glob_pred*Sa_pred)*cov_a_pred*(D_glob_pred*Sa_pred).';

n=size(cov_y_pred,1);

std_yr_pred=diag(cov_y_pred(1:n/2,1:n/2)).^0.5;
std_yi_pred=diag(cov_y_pred(n/2+1:end,n/2+1:end)).^0.5;
