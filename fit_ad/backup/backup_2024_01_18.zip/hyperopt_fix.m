function hyper=hyperopt_fix(hyper)

%%
if ~permopt(hyper.kernel,{'se' 'matern52' 'rq'})
    error(['Kernel option not permissible: ' hyper.kernel]);
end

if ~permopt(hyper.noise,{'model1' 'model2' 'model3' 'model3w' 'model4' 'model4w'})
    error(['Noise option not permissible: ' hyper.noise]);
end

if ~permopt(hyper.basis,{'zero' 'constant'})
    error(['Basis option not permissible: ' hyper.basis]);
end

%%

if strcmpi(hyper.noise,'model1')
    hyper.nv=1;
elseif strcmpi(hyper.noise,'model2')
    hyper.nv=2;
elseif strcmpi(hyper.noise,'model3')
    hyper.nv=2;
elseif strcmpi(hyper.noise,'model3w')
    hyper.nv=3;
elseif strcmpi(hyper.noise,'model4')
    hyper.nv=2;
elseif strcmpi(hyper.noise,'model4w')
    hyper.nv=4;
elseif strcmpi(hyper.noise,'model_a')
    hyper.nv=NaN;
end

hyper.na=hyper.nd+2;

% 
if isempty(hyper.ini.d)
    hyper.ini.d=linspace(min(hyper.lb.d),max(hyper.ub.d),hyper.na+2);
    hyper.ini.d=hyper.ini.d(2:end-1);
end

hyper.ini.d=hyper.ini.d(:);
hyper.lb.d=expandcol(hyper.lb.d,hyper.nv);
hyper.ub.d=expandcol(hyper.ub.d,hyper.nv);


% If scalars given, expand to vector
hyper.ini.sigma_v=expandcol(hyper.ini.sigma_v,hyper.nv);
hyper.lb.sigma_v=expandcol(hyper.lb.sigma_v,hyper.nv);
hyper.ub.sigma_v=expandcol(hyper.ub.sigma_v,hyper.nv);

hyper.ini.sigma=expandcol(hyper.ini.sigma,hyper.na);
hyper.lb.sigma=expandcol(hyper.lb.sigma,hyper.na);
hyper.ub.sigma=expandcol(hyper.ub.sigma,hyper.na);

hyper.ini.L=expandcol(hyper.ini.L,hyper.na);
hyper.lb.L=expandcol(hyper.lb.L,hyper.na);
hyper.ub.L=expandcol(hyper.ub.L,hyper.na);

hyper.alpha0=expandcol(hyper.alpha0,hyper.na);
hyper.lb.alpha=expandcol(hyper.lb.alpha,hyper.na);
hyper.ub.alpha=expandcol(hyper.ub.alpha,hyper.na);

hyper.abar0=expandcol(hyper.abar0,hyper.na);
hyper.lb.abar=expandcol(hyper.lb.abar,hyper.na);
hyper.ub.abar=expandcol(hyper.ub.abar,hyper.na);

if ~strcmpi(hyper.kernel,'rq')
    hyper.alpha0=[];
    hyper.lb.alpha=[];
    hyper.ub.alpha=[];
end

if strcmpi(hyper.basis,'zero')
    hyper.abar0=[];
    hyper.lb.abar=[];
    hyper.ub.abar=[];
end

%% Index

hyper.idx.d=[1:hyper.nd];
hyper.idx.sigma_v=hyper.idx.d(end)+[1:hyper.nv];
hyper.idx.sigma=hyper.idx.sigma_v(end)+[1:hyper.na];
hyper.idx.L=hyper.idx.sigma(end)+[1:hyper.na];

if strcmpi(hyper.kernel,'rq')
    hyper.idx.alpha=hyper.idx.L(end)+[1:hyper.na];
else
    hyper.idx.alpha=[];
end

if strcmpi(hyper.basis,'constant')
    hyper.idx.abar=hyper.idx.L(end)+[1:hyper.na];

    if strcmpi(hyper.kernel,'rq')
        hyper.idx.abar=hyper.idx.abar+hyper.na;
    end
else
    hyper.idx.abar=[];
end

end

function b=expandcol(a,n)

%%

b=a(:);

if length(b)==1
    b=b*ones(n,1);
end

end