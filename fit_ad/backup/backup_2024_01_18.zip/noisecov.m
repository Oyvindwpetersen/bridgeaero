function [N,N_grad]=noisecov(data_matrix,hyper)

%% Noise matrix
%
% Inputs:
% data_matrix: [n,2] matrix with inputs as columns
% hyper: struct with hyperparameter
%
% Outputs:
% N: [2n,2n] noise matrix
% N_grad: gradient of N wrt. sigma_v
%

%%

n=size(data_matrix,1);
In=speye(n);
Zn=In*0;

K=data_matrix(:,1);

if strcmpi(hyper.noise,'model3') | strcmpi(hyper.noise,'model3w') | strcmpi(hyper.noise,'model4') | strcmpi(hyper.noise,'model4w')
    % K_diag=diag(K);
    K_diag=spdiags(K(:),0,numel(K),numel(K));
    K_squared_diag=K_diag.^2;
end

% if strcmpi(hyper.noise,'model4') | strcmpi(hyper.noise,'model4w')
%     K_squared_diag=diag(K.^2);
% end

% if strcmpi(hyper.noise,'model_a')
%     [D_glob,xt_uni,D_glob_grad]=rf_matrix_multi(data_matrix,hyper.d);
%     nx=length(xt_uni);
%     [S]=restack_a(hyper.na,length(xt_uni));
% end

%% Noise matrix

if strcmpi(hyper.noise,'model1')

    N=hyper.sigma_v^2*eye(n);

    N_grad{1}=2*hyper.sigma_v(1)*eye(n);

elseif strcmpi(hyper.noise,'model2')

    N=blkdiag2(hyper.sigma_v(1)^2*In,hyper.sigma_v(2)^2*In);

    N_grad{1}=blkdiag2(hyper.sigma_v(1)^2*In,Zn,'sparse');
    N_grad{2}=blkdiag2(Zn,hyper.sigma_v(2)^2*In,'sparse');

elseif strcmpi(hyper.noise,'model3')

    N=blkdiag2(hyper.sigma_v(1)^2*In,hyper.sigma_v(2)^2*K_diag);
    
    N_grad{1}=blkdiag2(2*hyper.sigma_v(1)*In,Zn,'sparse');
    N_grad{2}=blkdiag2(Zn,2*hyper.sigma_v(2)*K_diag,'sparse');

elseif strcmpi(hyper.noise,'model3w')

    N=blkdiag2(hyper.sigma_v(1)^2*In,hyper.sigma_v(2)^2*K_diag)...
      +blkdiag2(Zn,hyper.sigma_v(3)^2*In);
    
    N_grad{1}=blkdiag2(2*hyper.sigma_v(1)*In,Zn,'sparse');
    N_grad{2}=blkdiag2(Zn,2*hyper.sigma_v(2)*K_diag,'sparse');
    N_grad{3}=blkdiag2(Zn,2*hyper.sigma_v(3)*In,'sparse');

elseif strcmpi(hyper.noise,'model4')

    N=blkdiag2(hyper.sigma_v(1)^2*K_squared_diag,hyper.sigma_v(2)^2*K_squared_diag);
    
    N_grad{1}=blkdiag2(2*hyper.sigma_v(1)*K_squared_diag,Zn,'sparse');
    N_grad{2}=blkdiag2(Zn,2*hyper.sigma_v(2)*K_squared_diag,'sparse');
    
elseif strcmpi(hyper.noise,'model4w')

    N=blkdiag2(hyper.sigma_v(1)^2*K_squared_diag,hyper.sigma_v(2)^2*K_squared_diag)...
     +blkdiag2(hyper.sigma_v(3)^2*In,hyper.sigma_v(4)^2*In);
    
    N_grad{1}=blkdiag2(2*hyper.sigma_v(1)*K_squared_diag,Zn,'sparse');
    N_grad{2}=blkdiag2(Zn,2*hyper.sigma_v(2)*K_squared_diag,'sparse');
    N_grad{3}=blkdiag2(hyper.sigma_v(3)^2*In,Zn,'sparse');
    N_grad{4}=blkdiag2(Zn,hyper.sigma_v(4)^2*In,'sparse');
    
% elseif strcmpi(hyper.noise,'model_a')

    % N=blkdiag2(hyper.sigma_v(1)^2*In,hyper.sigma_v(2)^2*In);
    %   +D_glob*S*hyper.sigma_v(3)^2*S.'*D_glob.';
    % 
    % N_grad{1}=blkdiag2(2*hyper.sigma_v(1)*In,Zn,'sparse');
    % N_grad{2}=blkdiag2(Zn,2*hyper.sigma_v(2)*In,'sparse');
    % N_grad{3}=D_glob*S*2*hyper.sigma_v(3)*S.'*D_glob.';
else
    error(['Noise type not recognized:' hyper.noise]);
end
