function hyper=hyperopt(varargin)

%% Options for kernel and hyperparameters
%
% Inputs:

%%

p=inputParser;
addParameter(p,'nd',3,@isnumeric)
addParameter(p,'kernel','se',@ischar)
addParameter(p,'noise','model1',@ischar)
addParameter(p,'basis','zero',@ischar)

addParameter(p,'d0',[],@isnumeric)
addParameter(p,'sigma_v0',[1e-3],@isnumeric)
addParameter(p,'sigma0',[1],@isnumeric)
addParameter(p,'L0',[1],@isnumeric)
addParameter(p,'alpha0',[1],@isnumeric)
addParameter(p,'abar0',[1],@isnumeric)

addParameter(p,'d_lb',[1e-1],@isnumeric)
addParameter(p,'sigma_v_lb',[1e-6],@isnumeric)
addParameter(p,'sigma_lb',[1e-2],@isnumeric)
addParameter(p,'L_lb',[1e-2],@isnumeric)
addParameter(p,'alpha_lb',[1e-2],@isnumeric)
addParameter(p,'abar_lb',[1e-2],@isnumeric)

addParameter(p,'d_ub',[3],@isnumeric)
addParameter(p,'sigma_v_ub',[1e1],@isnumeric)
addParameter(p,'sigma_ub',[1e2],@isnumeric)
addParameter(p,'L_ub',[1e1],@isnumeric)
addParameter(p,'alpha_ub',[1e2],@isnumeric)
addParameter(p,'abar_ub',[1e2],@isnumeric)

addParameter(p,'delta_d',0.05,@isnumeric)

parse(p,varargin{:})

hyper.nd=p.Results.nd;
hyper.kernel=p.Results.kernel;
hyper.noise=p.Results.noise;
hyper.basis=p.Results.basis;

hyper.ini.d=p.Results.d0;
hyper.ini.sigma_v=p.Results.sigma_v0;
hyper.ini.sigma=p.Results.sigma0;
hyper.ini.L=p.Results.L0;
hyper.alpha0=p.Results.alpha0;
hyper.abar0=p.Results.abar0;

hyper.lb.d=p.Results.d_lb;
hyper.lb.sigma_v=p.Results.sigma_v_lb;
hyper.lb.sigma=p.Results.sigma_lb;
hyper.lb.L=p.Results.L_lb;
hyper.lb.alpha=p.Results.alpha_lb;
hyper.lb.abar=p.Results.abar_lb;

hyper.ub.d=p.Results.d_ub;
hyper.ub.sigma_v=p.Results.sigma_v_ub;
hyper.ub.sigma=p.Results.sigma_ub;
hyper.ub.L=p.Results.L_ub;
hyper.ub.alpha=p.Results.alpha_ub;
hyper.ub.abar=p.Results.abar_ub;

hyper.delta_d=p.Results.delta_d;

%%

hyper=hyperopt_fix(hyper);




