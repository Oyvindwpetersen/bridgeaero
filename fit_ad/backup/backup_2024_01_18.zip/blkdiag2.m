function B=blkdiag2(varargin)
%% Fast block diagonal
%
% Code same as inbuildt except that blkdiag...
% ... has costly overhead checks
% ... always gives out full matrices, even if inputs are sparse
%
% Inputs:
% X1,X2,X3,...: matrices to stack
% Add 'sparse' or 's' to end of input to preserve sparseness
%
% Outputs:
% B: block-diagonal matrix
%

%%

% Assume supplied string at end implies sparse (if sparse input)
if isstr(varargin{end})

    B=matlab.internal.math.blkdiag(varargin{1:end-1});

else

    B=matlab.internal.math.blkdiag(varargin{:});

    % If sparse, make full
    if issparse(B)
        B=full(B);
    end

end
