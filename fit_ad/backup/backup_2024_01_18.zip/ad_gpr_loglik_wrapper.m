function [neg_logL,neg_logL_grad]=ad_gpr_loglik_wrapper(test_matrix,y,hyper,theta)

%%

hyper.d=theta(hyper.idx.d);
hyper.sigma_v=theta(hyper.idx.sigma_v);
hyper.sigma=theta(hyper.idx.sigma);
hyper.L=theta(hyper.idx.L);
hyper.alpha=theta(hyper.idx.alpha);
hyper.abar=theta(hyper.idx.abar);

[neg_logL,neg_logL_grad]=ad_gpr_loglik(test_matrix,y,hyper);


