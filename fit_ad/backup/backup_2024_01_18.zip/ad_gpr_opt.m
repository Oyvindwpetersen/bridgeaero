function [logL_opt,hyper]=ad_gpr_opt(test_matrix,yt_r,yt_i,hyper,varargin)

%% Optimization
%
% Inputs:

%%

p=inputParser;
addParameter(p,'globalsearch',false,@islogical)

parse(p,varargin{:})

globalsearch=p.Results.globalsearch;

%% Assign initial and bounds

theta0(hyper.idx.d,1)=hyper.ini.d;
theta0(hyper.idx.sigma_v,1)=hyper.ini.sigma_v;
theta0(hyper.idx.sigma,1)=hyper.ini.sigma;
theta0(hyper.idx.L,1)=hyper.ini.L;
theta0(hyper.idx.alpha,1)=hyper.alpha0;
theta0(hyper.idx.abar,1)=hyper.abar0;

theta_lb(hyper.idx.d,1)=hyper.lb.d;
theta_lb(hyper.idx.sigma_v,1)=hyper.lb.sigma_v;
theta_lb(hyper.idx.sigma,1)=hyper.lb.sigma;
theta_lb(hyper.idx.L,1)=hyper.lb.L;
theta_lb(hyper.idx.alpha,1)=hyper.lb.alpha;
theta_lb(hyper.idx.abar,1)=hyper.lb.abar;

theta_ub(hyper.idx.d,1)=hyper.ub.d;
theta_ub(hyper.idx.sigma_v,1)=hyper.ub.sigma_v;
theta_ub(hyper.idx.sigma,1)=hyper.ub.sigma;
theta_ub(hyper.idx.L,1)=hyper.ub.L;
theta_ub(hyper.idx.alpha,1)=hyper.ub.alpha;
theta_ub(hyper.idx.abar,1)=hyper.ub.abar;

if any(theta_lb>=theta_ub)

    idx=find(theta_lb>theta_ub)
    error('theta lower bounds exceed upper bounds for elements index displayed above');

end

%%

% D_glob=diag(D_r1,D_r2,...,D_i1,D_i2,...)

% Kernel is created for restacked a

% | b_r(x1,K1) | = | D_r(K1)   0     | | a(x1) |
% | b_r(x2,K2) |   | 0       D_r(K2) | | a(x2) |
% | b_i(x1,K1) |   | D_i(K1)    0    | 
% | b_i(x2,K2) |   |  0      D_i(K2) | 
%

%%

y=[yt_r ; yt_i];

fun_obj= @(theta) ad_gpr_loglik_wrapper(test_matrix,y,hyper,theta);

options = optimoptions('fmincon','Display','iter','TypicalX',theta0,'ConstraintTolerance',1e-3,'OptimalityTolerance',1e-3,'StepTolerance',1e-3... ); %,...
    ,'CheckGradients',false,'Algorithm','interior-point','SpecifyObjectiveGradient',true);
% interior-point
% trust-region-reflective

% Constraint to separate deltas
A=zeros(hyper.nd-1,length(theta0));
for k=1:(hyper.nd-1)
    A(k,k-1+[1:2])=[1 -1];
end
b=-hyper.delta_d*ones(hyper.nd-1,1);
% A=[];
% b=[];

if ~globalsearch

[theta_opt,logL_opt]=fmincon(fun_obj,theta0,A,b,[],[],theta_lb,theta_ub,[],options);

d_opt=theta_opt(hyper.idx.d);
sigma_v_opt=theta_opt(hyper.idx.sigma_v);
sigma_opt=theta_opt(hyper.idx.sigma);
L_opt=theta_opt(hyper.idx.L);
alpha_opt=theta_opt(hyper.idx.alpha);
abar_opt=theta_opt(hyper.idx.abar);

end

%%

if globalsearch

problem = createOptimProblem('fmincon','objective',fun_obj,'x0',theta0,...
         'lb',theta_lb,'ub',theta_ub,'Aineq',A,'bineq',b,'options',options);

gs=GlobalSearch;
gs.BasinRadiusFactor=0.5;
gs.FunctionTolerance=1e-3;
gs.XTolerance=1e-3;
gs.StartPointsToRun='bounds-ineqs';
gs.NumStageOnePoints=100; %200
gs.NumTrialPoints=500; %1000

% t0=tic;
[theta_opt_glob,logL_opt,~,~,manymins]=run(gs,problem);
% t1=toc(t0);

theta_opt=theta_opt_glob;

d_opt=theta_opt(hyper.idx.d);
sigma_v_opt=theta_opt(hyper.idx.sigma_v);
sigma_opt=theta_opt(hyper.idx.sigma);
L_opt=theta_opt(hyper.idx.L);
alpha_opt=theta_opt(hyper.idx.alpha);
abar_opt=theta_opt(hyper.idx.abar);

end

%%

hyper.d=d_opt;
hyper.sigma_v=sigma_v_opt;
hyper.sigma=sigma_opt;
hyper.L=L_opt;
hyper.alpha=alpha_opt;
hyper.abar=abar_opt;
