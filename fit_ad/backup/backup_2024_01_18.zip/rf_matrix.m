function [Dr,Di]=rf_matrix(d,K)
%% Regression matrix in fit of aerodynamic derivatives using rational functions
%
% Inputs:
% d: vector with poles
% K: vector with frequencies
%
% Outputs:
% Dr: regression matrix for real part (K^2*AD_stiffness)
% Di: regression matrix for imaginary part (K^2*AD_damping)
%

%%

% Ensure column
K=K(:);

% Ensure row
d=d(:).';

D_real_qs=[ones(length(K),1) zeros(length(K),1)];
D_imag_qs=[zeros(length(K),1) K];

D_real_rf=K.^2./(d.^2+K.^2);
D_imag_rf=d.*K./(d.^2+K.^2);

Dr=[D_real_qs D_real_rf];
Di=[D_imag_qs D_imag_rf];

